# Trading Journal — installable web app

This folder is a standalone version of your trading journal, set up as a
Progressive Web App (PWA) so it can be installed to an Android home screen
like a native app. See the note at the bottom on why this is a PWA and not
a compiled `.apk`.

## Get it on your phone (about 2 minutes)

A PWA needs to be served over **HTTPS** for install + offline to work —
opening `index.html` straight from a folder on your phone will run the app
fine, but Chrome won't offer to install it. Easiest free option:

1. Create a new GitHub repository and upload all 6 files in this folder to it
   (`index.html`, `manifest.json`, `service-worker.js`, `icon-192.png`,
   `icon-512.png`, this `README.md`).
2. In the repo: **Settings → Pages** → set source to your main branch → **Save**.
3. GitHub gives you a URL like `https://yourname.github.io/repo-name/`.
4. Open that URL on your Android phone in **Chrome**.
5. Tap the **⋮** menu → **Add to Home screen** / **Install app**.

It now opens full-screen with its own icon, no browser bar, works offline
after the first load, and needs no login. Netlify, Vercel, and Cloudflare
Pages all work the same way if you'd rather drag-and-drop the folder instead.

## About your data

Entries and starting capital now save to the phone's browser storage
(`localStorage`) instead of Claude's artifact storage, since this version
runs outside Claude:

- Data stays on that device, tied to that browser/PWA install.
- Clearing Chrome's site data for the app will erase it — there's no cloud
  backup or sync.
- It does **not** share data with the version you used inside Claude, or
  with any other device — each install has its own local journal.

## Why this is a PWA and not a `.apk`

A real, installable `.apk` has to be compiled and signed with Android's
official build tools (the Android SDK + Gradle), which pull from Google's
own servers. That infrastructure isn't reachable from the sandbox this was
built in, so producing and handing you a working signed APK directly isn't
something I can do here — and I'd rather tell you that than hand you a file
that fails to install.

If you specifically want a native `.apk` to sideload (not just this
installed web app), I can write you a minimal Android Studio project
(Kotlin + Gradle) that wraps this same page in a WebView. You'd build it
yourself with Android Studio — `./gradlew assembleDebug` or hit Run — since
that final compile step needs Google's Maven repository. Just ask.
